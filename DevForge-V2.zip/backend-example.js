// DevForge V2 backend example (Cloudflare Worker-style).
// Put your AI provider secret in the server environment, NEVER in index.html/script.js.
// Adapt callProvider() to your provider's server-side SDK/API.

export default {
  async fetch(request, env) {
    const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"POST, OPTIONS"};
    if(request.method==="OPTIONS") return new Response(null,{headers:cors});
    if(request.method!=="POST") return Response.json({error:"POST only"},{status:405,headers:cors});
    try{
      const {prompt,currentCode}=await request.json();
      if(!prompt) return Response.json({error:"Missing prompt"},{status:400,headers:cors});
      const result=await callProvider(prompt,currentCode,env);
      return Response.json(result,{headers:cors});
    }catch(e){
      return Response.json({error:e.message},{status:500,headers:cors});
    }
  }
};

async function callProvider(prompt,currentCode,env){
  // Replace this demo return with your server-side AI provider call.
  // Require the model to return ONLY JSON:
  // {"name":"App name","html":"...","css":"...","js":"..."}
  return {
    name:"AI Backend Connected",
    html:`<main><h1>Backend connected ✅</h1><p>Your prompt was: ${escapeHtml(prompt)}</p></main>`,
    css:"body{font-family:system-ui;background:#0f172a;color:white;display:grid;place-items:center;min-height:100vh}main{max-width:600px;padding:30px}",
    js:"console.log('Connect callProvider() to your AI provider.')"
  };
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
