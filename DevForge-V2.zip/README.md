# DevForge V2

Upload `index.html`, `style.css`, and `script.js` to GitHub Pages.

## Modes
- Smart Demo: works immediately with no server.
- Real AI: click **AI Setup** and enter your own HTTPS serverless endpoint.

## Backend contract
POST JSON:
`{"prompt":"...","currentCode":{"html":"...","css":"...","js":"..."}}`

Return JSON:
`{"name":"...","html":"...","css":"...","js":"..."}`

`backend-example.js` shows the endpoint shape. Keep AI provider secrets on the server, not in public GitHub Pages files.
